<?php
$root=str_replace(DIRECTORY_SEPARATOR.'ajax', '', realpath(dirname(__FILE__)));
define('__TAMMANAGER',1);
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'configs.php';
if($_SESSION['user']['username']!=$configs['username']||$_SESSION['user']['password']!=$configs['password']||!$_SESSION['xt']['token']){
	header('location:'.$configs['manager_url'].'/login.php');
	exit;
}
?><!DOCTYPE html>
<html lang="vi" xml:lang="vi" xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Quản lý tập tin</title>
		<meta content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0" name="viewport" />
		<link rel="stylesheet" href="<?php echo $configs['manager_url']; ?>/style/tamManager.min.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo $configs['manager_url']; ?>/style/font-awesome.min.css" type="text/css" />
		<script src="<?php echo $configs['manager_url']; ?>/js/jquery.js" type="text/javascript"></script>
		<script src="<?php echo $configs['manager_url']; ?>/js/multiselect.js" type="text/javascript"></script>
		<script src="<?php echo $configs['manager_url']; ?>/js/ContextMenu.js" type="text/javascript"></script>
		<link href="<?php echo $configs['manager_url']; ?>/images/favicon.png" rel="icon" type="image/x-icon" />
		<script type="text/javascript">
			var manager_url='<?php echo $configs['manager_url']; ?>';
		</script>
	</head>
	<body>
		<div class="main-body">
			<header>
				<div class="logo">
					<img src="<?php echo $configs['manager_url']; ?>/images/logo.png" alt="TamManager" />
				</div>
   				<div class="usercontrol">
					<a href="<?php echo $configs['manager_url']; ?>" class="username">
                        <i class="fa fa-user"></i>
                        <span><?php echo $_SESSION['xt']['title']; ?></span>
                    </a>
					<a href="<?php echo $configs['manager_url']; ?>/logout.php" class="logout">
                        <i class="fa fa-sign-out"></i>
                    </a>
				</div>
			</header>
			<div class="clear"></div>
			<div class="section">
				<ul class="control-list">
					<li><a href="javascript:;" id="control-newfile" onclick="showNewFileControl();"><i class="fa fa-plus"></i> File</a></li>
					<li><a href="javascript:;" id="control-newfolder" onclick="showNewDirControl();"><i class="fa fa-plus"></i> Folder</a></li>
					<li><a href="javascript:;" id="control-copy" class="disable" onclick="showCopysControl();"><i class="fa fa-files-o"></i> Copy</a></li>
					<li><a href="javascript:;" id="control-move" class="disable" onclick="showMovesControl();"><i class="fa fa-cut"></i> Move</a></li>
					<li><a href="javascript:;" id="control-upload" onclick="showUploadControl();"><i class="fa fa-upload"></i> Upload</a></li>
					<li><a href="javascript:;" id="control-import" onclick="showImportControl();"><i class="fa fa-link"></i> Import</a></li>
					<li><a href="javascript:;" id="control-download" class="disable" onclick="showDownloadControl();"><i class="fa fa-download"></i> Download</a></li>
					<li><a href="javascript:;" id="control-delete" class="disable" onclick="showDeletesControl();"><i class="fa fa-remove"></i> Delete</a></li>
					<li><a href="javascript:;" id="control-unzip" onclick="showUnzipControl();"><i class="fa fa-expand"></i> Unzip</a></li>
				</ul>
				<ul class="sub-control-list">
					<li><a href="javascript:;" onclick="loadData('/');"><i class="fa fa-home fa-lg"></i> Home</a></li>
					<li><a href="javascript:;" id="backData" onclick="loadBackData();" class="disable"><i class="fa fa-arrow-left"></i> Back</a></li>
					<li><a href="javascript:;" onclick="reloadData();"><i class="fa fa-refresh"></i> Refresh</a></li>
					<li><a href="javascript:;" id="control-selectall" onclick="selectAll();"><i class="fa fa-check-square-o"></i> Select All</a></li>
					<li><a href="javascript:;" id="control-unselectall" onclick="unselectAll();" class="disable"><i class="fa fa-square-o"></i> Unselect All</a></li>
					<li><a href="javascript:;" id="control-openmenu" class="disable"><i class="fa fa-list"></i> Menu</a></li>
				</ul>
				<div class="file-list">
					<div class="file-list-th">
						<span class="file-list-th-icon">&nbsp;</span>
						<span class="file-list-th-name">Name</span>
					</div>
					<div class="file-scroll-list">
						<ul class="file-list-td" id="file-list-data"></ul>
					</div>
				    <ul id="file-popup"></ul>
				</div>
				<div class="info-list">0 thư mục / 0 tập tin</div>
				<div class="background-popup"></div>
				<div class="background-form-popup"></div>
				<script src="<?php echo $configs['manager_url']; ?>/js/tamManager.min.js" type="text/javascript"></script>
			</div>
			<footer>
				<p>TamManager by <a href="http://KENHVH.MOBIE.IN" title="KENHVH">KENHVH</a> © 2016</p>
			</footer>
		</div>
	</body>
</html>