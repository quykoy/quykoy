<?php
/**********************************/
/*  Xtgem & Sextgem Mangager      */
/*  Code by MrTam 				  */
/*  Email: mr.trinhtam@yahoo.com  */
/*  Website: http://taigi.org 	  */
/**********************************/

$root=str_replace(DIRECTORY_SEPARATOR.'ajax', '', realpath(dirname(__FILE__)));
define('__TAMMANAGER',1);
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'configs.php';
if($_SESSION['user']['username']!=$configs['username']||$_SESSION['user']['password']!=$configs['password']||!$_SESSION['xt']['token']){
	echo json_encode(array('list'=>'not_login'));
	exit;
}
include $root.'/sys/xtapi.php';
$dir=str_replace('//', '/', ($_GET['dir_path']?$_GET['dir_path']:'/'));
$reback=pathinfo($dir);
$reback=($reback['dirname']!='\\'?$reback['dirname']:'/');
$list=showFullDir($dir);
if($list=='not_login'){
	echo json_encode(array('list'=>'not_login'));
	exit;
}
$html='';
$cnt_dir=count($list['dirs']['name']);
if($cnt_dir){
	foreach ($list['dirs']['name'] as $key=>$value) {
		$html.='<li>
			<span class="file-list-td-icon"><img src="'.$configs['manager_url'].'/images/icons/dir.png" /></span>
			<span class="file-list-td-name">'.$list['dirs']['name'][$key].'</span>
			<input type="hidden" name="type" value="dir" />
			<input type="hidden" name="path" value="'.urldecode($list['dirs']['link'][$key]).'" />
		</li>';
	}
}
$cnt_file=count($list['files']['name']);
if($cnt_file){
	foreach ($list['files']['name'] as $key=>$value) {
		$html.='<li>
			<span class="file-list-td-icon"><img src="'.$configs['manager_url'].'/images/icons/'.($configs['icons'][$list['files']['type'][$key]]?$configs['icons'][$list['files']['type'][$key]]:'default.png').'" /></span>
			<span class="file-list-td-name">'.$list['files']['name'][$key].'</span>
			<input type="hidden" name="type" value="'.$list['files']['type'][$key].'" />
			<input type="hidden" name="path" value="'.urldecode($list['files']['link'][$key]).'" />
		</li>';
	}
}
echo json_encode(array('list'=>($html?$html:'<div class="nodata">Danh sách rỗng</div>'),'info'=>$cnt_dir.' thư mục / '.$cnt_file.' tập tin','reback'=>$reback));
