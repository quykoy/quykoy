<?php
/**********************************/
/*  Xtgem & Sextgem Mangager      */
/*  Code by MrTam 				  */
/*  Email: mr.trinhtam@yahoo.com  */
/*  Website: http://taigi.org 	  */
/**********************************/
if($_POST){
	$root=str_replace(DIRECTORY_SEPARATOR.'ajax', '', realpath(dirname(__FILE__)));
	define('__TAMMANAGER',1);
	include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'configs.php';
	if(!$_POST['username']||!$_POST['password']){
		echo json_encode(array('status'=>'error','message'=>'Bạn phải điền đầy đủ username hoặc password'));
		exit;
	}else if($_POST['username']!=$configs['username']){
		echo json_encode(array('status'=>'error','message'=>'Tên đăng nhập hoặc mật khẩu không đúng'));
		exit;
	}else  if($_POST['password']!=$configs['password']){
		echo json_encode(array('status'=>'error','message'=>'Tên đăng nhập hoặc mật khẩu không đúng'));
		exit;
	}else{
		$_SESSION['user']['username']=$_POST['username'];
		$_SESSION['user']['password']=$_POST['password'];
		$cnt=count($configs['autologin']);
		if($cnt<1){
			echo json_encode(array('status'=>'error','message'=>'Bạn chưa thiết lập tài khoản autologin'));
			exit;
		}else if($cnt==1){
			$_SESSION['xt']=$configs['autologin'][0];
			$ur = parse_url($configs['autologin'][0]['link']);
			$_SESSION['xt']['host']='http://'.$ur['host'];
			include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'xtapi.php';
			if(login()){
				$ur = propertiesFile();
				$_SESSION['xt']['site']=$ur['link'];
				echo json_encode(array('status'=>'success','message'=>'Đăng nhập thành công','action'=>'1'));
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Không thể đăng nhập vào '.$configs['autologin'][0]['title']));
				exit;
			}
		}else{
			$jp='<div class="form-popup"><div class="title-popup">Chọn tài khoản</div><div class="main-popup"><form id="setlogin" method="post"><input type="hidden" id="account" value="0" /><p class="status"></p><p><ul class="file-upload-list">';
			foreach($configs['autologin'] as $key => $value){
			$jp.='<li class="dir-list-items"><i class="fa fa-user"></i> '.$value['title'].'<input type="hidden" name="id" value="'.$key.'" /></li>';
			}
			$jp.='</ul></p><p><input type="submit" class="button color1" value="Đăng nhập" /></p></div></div>';
			echo json_encode(array('status'=>'success','message'=>$jp,'action'=>'2'));
			exit;
		}
	}
}
