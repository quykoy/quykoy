<?php
/**********************************/
/*  Xtgem & Sextgem Mangager      */
/*  Code by MrTam 				  */
/*  Email: mr.trinhtam@yahoo.com  */
/*  Website: http://taigi.org 	  */
/**********************************/
$root=str_replace(DIRECTORY_SEPARATOR.'ajax', '', realpath(dirname(__FILE__)));
define('__TAMMANAGER',1);
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'configs.php';
if($_SESSION['user']['username']!=$configs['username']||$_SESSION['user']['password']!=$configs['password']||!$_SESSION['xt']['token']){
	echo json_encode(array('list'=>'not_login'));
	exit;
}
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'xtapi.php';
$dir=str_replace('//', '/', ($_GET['dir_path']?$_GET['dir_path']:'/'));
$reback=pathinfo($dir);
$reback=($reback['dirname']!='\\'?$reback['dirname']:'/');
$list=showDir($dir);
if($list=='not_login'){
	echo json_encode(array('list'=>'not_login'));
	exit;
}
$html='';
if(is_array($list)){
	foreach ($list['name'] as $key=>$value) {
		$html.='<li class="dir-list-items"><img src="'.$configs['manager_url'].'/images/icons/dir.png" /> '.$value.'
			<input type="hidden" name="path" value="'.urldecode($list['link'][$key]).'" /></li>';
	}
}
echo json_encode(array('list'=>($html?$html:'<div class="nodir">Không có thư mục khác</div>'),'reback'=>$reback,'indir'=>$dir));
