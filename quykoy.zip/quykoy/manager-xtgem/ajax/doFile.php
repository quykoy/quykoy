<?php
/**********************************/
/*  Xtgem & Sextgem Mangager      */
/*  Code by MrTam 				  */
/*  Email: mr.trinhtam@yahoo.com  */
/*  Website: http://taigi.org 	  */
/**********************************/
$root=str_replace(DIRECTORY_SEPARATOR.'ajax', '', realpath(dirname(__FILE__)));
define('__TAMMANAGER',1);
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'configs.php';
if($_SESSION['user']['username']!=$configs['username']||$_SESSION['user']['password']!=$configs['password']||!$_SESSION['xt']['token']){
	echo json_encode(array('status'=>'error','message'=>'Truy cập không hợp lệ'));
	exit;
}
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'xtapi.php';
$dir=str_replace('//', '/', ($_GET['dir_path']?$_GET['dir_path']:'/'));
switch ($_GET['action']){
	case 'checkdir':
		checkDir($dir);
		break;
	case 'mvdirunzip':
		rmFullDir($root.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'tmp_unzip');
		break;
	case 'upload':
		if($_GET['file']){
			$file=$root.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'tmp_upload'.DIRECTORY_SEPARATOR.$_GET['file'];
			$check=uploadFile($file, $dir);
			if($check==1){
				echo 'success';
				@unlink($file);
				exit;
			}else if($check=='not_login'){
				echo 'not_login';
				@unlink($file);
				exit;
			}else{
				echo 'error';
				@unlink($file);
				exit;
			}
		}else{
			echo 'error';
			exit;
		}
		break;
	case 'unzip_upload':
		if($_POST['path']&&$_POST['file']){
			$file=$root.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'tmp_unzip'.DIRECTORY_SEPARATOR.$_POST['local'].DIRECTORY_SEPARATOR.$_POST['file'];
			$check=uploadFile($file, $_POST['path']);
			if($check==1){
				echo json_encode(array('status'=>'success','message'=>'Thành công'));
				@unlink($file);
				exit;
			}else if($check=='not_login'){
				echo json_encode(array('status'=>'not_login','message'=>'Chưa đăng nhập'));
				@unlink($file);
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Không thành công'));
				@unlink($file);
				exit;
			}
		}else{
			echo json_encode(array('status'=>'error','message'=>'Không thành công'));
			exit;
		}
		break;
	case 'unzip_adddir':
		if($_POST['path']&&$_POST['file']){
			$check=newDir($_POST['path'], $_POST['file']);
			if($check==1){
				echo json_encode(array('status'=>'success','message'=>'Thành công'));
				exit;
			}else if($check=='not_login'){
				echo json_encode(array('status'=>'not_login','message'=>'Chưa đăng nhập'));
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Không thành công'));
				exit;
			}
		}else{
			echo json_encode(array('status'=>'error','message'=>'Không thành công'));
			exit;
		}
		break;
	case 'import':
		if($_POST['link']){
			$check=importFile($_POST['link'], $dir);
			if($check==1){
				echo json_encode(array('status'=>'success','message'=>'Import thành công'));
				exit;
			}else if($check=='not_login'){
				echo json_encode(array('status'=>'not_login','message'=>'Chưa đăng nhập'));
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Import thành công'));
				exit;
			}
		}else{
			echo json_encode(array('status'=>'error','message'=>'Thao tác không hợp lệ'));
			exit;
		}
		break;
	case 'addfile':
		if($_POST['filename']){
			$check=newFile($dir, $_POST['filename']);
			if($check==1){
				echo json_encode(array('status'=>'success','message'=>'Tạo thành công'));
				exit;
			}else if($check=='not_login'){
				echo json_encode(array('status'=>'not_login','message'=>'Chưa đăng nhập'));
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Tập tin đã tồn tại'));
				exit;
			}
		}else{
			echo json_encode(array('status'=>'error','message'=>'Thao tác không hợp lệ'));
			exit;
		}
		break;
	case 'adddir':
		if($_POST['filename']){
			$check=newDir($dir, $_POST['filename']);
			if($check==1){
				echo json_encode(array('status'=>'success','message'=>'Tạo thành công'));
				exit;
			}else if($check=='not_login'){
				echo json_encode(array('status'=>'not_login','message'=>'Chưa đăng nhập'));
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Thư mục đã tồn tại'));
				exit;
			}
		}else{
			echo json_encode(array('status'=>'error','message'=>'Thao tác không hợp lệ'));
			exit;
		}
		break;
	case 'rename':
		if($_POST['filename']){
			$check=renameFile($_POST['filename'], $_POST['oldname']);
			if($check==1){
				echo json_encode(array('status'=>'success','message'=>'Thay đổi thành công'));
				exit;
			}else if($check=='not_login'){
				echo json_encode(array('status'=>'not_login','message'=>'Chưa đăng nhập'));
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Không thể thay đổi'));
				exit;
			}
		}else{
			echo json_encode(array('status'=>'error','message'=>'Thao tác không hợp lệ'));
			exit;
		}
		break;
	case 'delete':
		if($_POST['filename']){
			$check=removeFile($_POST['filename'],$_POST['type']);
			if($check==1){
				echo json_encode(array('status'=>'success','message'=>'Xóa thành công'));
				exit;
			}else if($check=='not_login'){
				echo json_encode(array('status'=>'not_login','message'=>'Chưa đăng nhập'));
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Không thể xóa'));
				exit;
			}
		}else{
			echo json_encode(array('status'=>'error','message'=>'Thao tác không hợp lệ'));
			exit;
		}
		break;
	case 'copy':
		if($_POST['oldfile']&&$_POST['newdir']){
			$check=copyFile($_POST['oldfile'],$_POST['newdir'].'/');
			if($check==1){
				echo json_encode(array('status'=>'success','message'=>'Sao chép thành công'));
				exit;
			}else if($check=='not_login'){
				echo json_encode(array('status'=>'not_login','message'=>'Chưa đăng nhập'));
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Không thể sao chép'));
				exit;
			}
		}else{
			echo json_encode(array('status'=>'error','message'=>'Thao tác không hợp lệ'));
			exit;
		}
		break;
	case 'move':
		if($_POST['oldfile']&&$_POST['newdir']){
			$check=moveFile($_POST['oldfile'],$_POST['newdir'].'/');
			if($check==1){
				echo json_encode(array('status'=>'success','message'=>'Di chuyển thành công'));
				exit;
			}else if($check=='not_login'){
				echo json_encode(array('status'=>'not_login','message'=>'Chưa đăng nhập'));
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Không thể di chuyển'));
				exit;
			}
		}else{
			echo json_encode(array('status'=>'error','message'=>'Thao tác không hợp lệ'));
			exit;
		}
		break;
	case 'download':
		if($_POST['file']){
			$check=downloadFile($_POST['file']);
			if(file_exists($root.'/files/download/'.$check)){
				echo json_encode(array('status'=>'success','message'=>'Tải thành công','path'=>$check));
				exit;
			}else if($check=='not_login'){
				echo json_encode(array('status'=>'not_login','message'=>'Chưa đăng nhập'));
				exit;
			}else{
				echo json_encode(array('status'=>'error','message'=>'Không thể tải về'));
				exit;
			}
		}else{
			echo json_encode(array('status'=>'error','message'=>'Thao tác không hợp lệ'));
			exit;
		}
		break;
	default:
		echo json_encode(array('status'=>'error','message'=>'Truy cập không hợp lệ'));
		exit;
		break;
}