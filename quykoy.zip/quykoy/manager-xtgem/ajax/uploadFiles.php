<?php
/**********************************/
/*  Xtgem & Sextgem Mangager      */
/*  Code by MrTam 				  */
/*  Email: mr.trinhtam@yahoo.com  */
/*  Website: http://taigi.org 	  */
/**********************************/
$root=str_replace(DIRECTORY_SEPARATOR.'ajax', '', realpath(dirname(__FILE__)));
define('__TAMMANAGER',1);
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'configs.php';
if($_SESSION['user']['username']!=$configs['username']||$_SESSION['user']['password']!=$configs['password']||!$_SESSION['xt']['token']){
	echo json_encode(array('status'=>'error','message'=>'Truy cập không hợp lệ'));
	exit;
}
$type=strtolower(end(explode('.',$_FILES['files']['name'])));
$filename=$_FILES['files']['name'];
if(copy($_FILES['files']['tmp_name'],$root.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'tmp_upload'.DIRECTORY_SEPARATOR.$filename)){
	echo json_encode(array(
		'status' => 'success',
		'name' => $filename,
		'type' =>  $type,
	));
	exit;
}else{
	echo json_encode(array(
		'status' => 'error',
		'name' => $filename,
		'type' =>  $type,
	));
	exit;
}