<?php
/**********************************/
/*  Xtgem & Sextgem Mangager      */
/*  Code by MrTam 				  */
/*  Email: mr.trinhtam@yahoo.com  */
/*  Website: http://taigi.org 	  */
/**********************************/
$root=str_replace(DIRECTORY_SEPARATOR.'ajax', '', realpath(dirname(__FILE__)));
define('__TAMMANAGER',1);
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'configs.php';
if($_SESSION['user']['username']!=$configs['username']||$_SESSION['user']['password']!=$configs['password']||!$_SESSION['xt']['token']){
	echo json_encode(array('status'=>'error','message'=>'Truy cập không hợp lệ'));
	exit;
}
$dir=str_replace('//', '/', ($_GET['dir_path']?$_GET['dir_path']:'/'));
$type=strtolower(end(explode('.',$_FILES['files']['name'])));
if($type=='zip'){
	$filename=$root.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'tmp_upload'.DIRECTORY_SEPARATOR.$_FILES['files']['name'];
	if(copy($_FILES['files']['tmp_name'],$filename)){
		include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'pclzip.php';
		$zip=new PclZip($filename);
		if(($list=$zip->listContent())==0){
			echo json_encode(array(
				'status' => 'error',
				'message' =>  'Không có file trong file nén',
			));
			unlink($filename);
			exit;
		}else{
			if(!is_dir($root.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'tmp_unzip')){
				mkdir($root.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'tmp_unzip');
			}
			if($zip->extract(PCLZIP_OPT_PATH,$root.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'tmp_unzip')){
				$cnt=sizeof($list);
				for($i=0; $i<$cnt; $i++){
					$path=pathinfo($list[$i]['filename']);
			  		if(is_dir($root.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'tmp_unzip'.DIRECTORY_SEPARATOR.$path['dirname'].DIRECTORY_SEPARATOR.$path['basename'])){
				        $js[$i]=array('action'=>'unzip_adddir','local'=>$path['dirname'],'path'=>$dir.($path['dirname']!='.'?'/'.$path['dirname']:''),'file'=>$path['basename']);
				    }else{
				        $js[$i]=array('action'=>'unzip_upload','local'=>$path['dirname'],'path'=>$dir.'/'.$path['dirname'],'file'=>$path['basename']);
				    }
				}
				echo json_encode(array(
					'status' => 'success',
					'message' => json_encode($js),
				));
				unlink($filename);
				exit;
			}else{
				echo json_encode(array(
					'status' => 'error',
					'message' =>  'File nén có lẽ bị lỗi',
				));
				unlink($filename);
				exit;
			}
		}
	}else{
		echo json_encode(array(
			'status' => 'error',
			'message' =>  'Không thể Upload file nén',
		));
		exit;
	}
}else{
	echo json_encode(array(
		'status' => 'error',
		'message' =>  'Chỉ hỗ trợ định dạng .zip',
	));
	exit;
}