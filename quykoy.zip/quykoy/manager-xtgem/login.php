<?php
$root=str_replace(DIRECTORY_SEPARATOR.'ajax', '', realpath(dirname(__FILE__)));
define('__TAMMANAGER',1);
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'configs.php';
$msg='';
if($_GET['account']){
	if($_SESSION['user']['username']==$configs['username']&&$_SESSION['user']['password']==$configs['password']){
		$_SESSION['xt']=$configs['autologin'][$_GET['account']];
		$ur = parse_url($configs['autologin'][$_GET['account']]['link']);
		$_SESSION['xt']['host']='http://'.$ur['host'];
		include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'xtapi.php';
		if(login()){
			$ur = propertiesFile();
			$_SESSION['xt']['site']=$ur['link'];
			header('location:'.$configs['manager_url']);
			exit;
		}else{
			$msg='Không thể đăng nhập tài khoản đã chọn';
		}
	}
}
?><!DOCTYPE html>
<html lang="vi" xml:lang="vi" xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Đăng nhập quản trị</title>
		<meta content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0" name="viewport" />
		<link rel="stylesheet" href="<?php echo $configs['manager_url']; ?>/style/tamManager.min.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo $configs['manager_url']; ?>/style/font-awesome.min.css" type="text/css" />
		<script src="<?php echo $configs['manager_url']; ?>/js/jquery.js" type="text/javascript"></script>
		<script src="<?php echo $configs['manager_url']; ?>/js/login.js" type="text/javascript"></script>
		<link href="<?php echo $configs['manager_url']; ?>/images/favicon.png" rel="icon" type="image/x-icon" />
		<script type="text/javascript">
			var manager_url='<?php echo $configs['manager_url']; ?>';
		</script>
	</head>
	<body>
		<div class="main-body">
			<header>
				<div class="logo">
					<img src="<?php echo $configs['manager_url']; ?>/images/logo.png" alt="TamManager" />
				</div>
			</header>
			<div class="section">
				<form id="login">
				    <div id="login-status"><?php echo $msg; ?></div>
				    <div class="input-group">
				        <span class="input-group-addon"><i class="fa fa-user"></i></span>
				        <input type="text" id="username" placeholder="Username">
				    </div>
				    <div class="input-group">
				        <span class="input-group-addon"><i class="fa fa-key"></i></span>
				        <input type="password" id="password" placeholder="Password">
					</div>
				    <div class="input-button-group">
						<input type="submit" id="loginSubmit" value="Login" />
					</div>
				</form>
			</div>
			<div class="background-popup"></div>
			<div class="background-form-popup"></div>
			<footer>
				<p>TamManager by <a href="http://KENHVH.MOBIE.IN" title="KENHVH">KENHVH</a> © 2016</p>
			</footer>
		</div>
	</body>
</html>