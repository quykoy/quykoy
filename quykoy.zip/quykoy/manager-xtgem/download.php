<?php
$root=str_replace(DIRECTORY_SEPARATOR.'ajax', '', realpath(dirname(__FILE__)));
define('__TAMMANAGER',1);
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'configs.php';
if($_GET['file']){
	$file=$root.DIRECTORY_SEPARATOR.'files'.DIRECTORY_SEPARATOR.'download'.DIRECTORY_SEPARATOR.$_GET['file'];
	if(file_exists($file)){
	  	header("Cache-Control: public");
	    header("Content-Description: File Transfer");
	    header("Content-Disposition: attachment; filename=".end(explode('/', $_GET['file'])));
	    header("Content-Transfer-Encoding: binary");
	    readfile($file);
	}
}