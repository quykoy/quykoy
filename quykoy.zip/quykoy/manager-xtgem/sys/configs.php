<?php
/**********************************/
/*  Xtgem & Sextgem Mangager      */
/*  Code by MrTam 				  */
/*  Email: mr.trinhtam@yahoo.com  */
/*  Website: http://taigi.org 	  */
/**********************************/
error_reporting(0);
// ini_set('display_errors', 1);
if(!defined('__TAMMANAGER')) exit('Truy cap khong hop le');

@ob_start();
@session_start();
date_default_timezone_set("Asia/Ho_Chi_Minh");

// Icon file
$configs['icons'] = array('3gp'=>'3gp.png', 'avi'=>'avi.png', 'bmp'=>'bmp.png', 'cldir'=>'cldir.png', 'css'=>'css.png', 'default'=>'default.png', 'dir'=>'dir.png', 'doc'=>'doc.png', 'exe'=>'exe.png', 'fla'=>'fla.png', 'gif'=>'gif.png', 'htaccess'=>'htaccess.png', 'htm'=>'htm.png', 'html'=>'html.png', 'jad'=>'jad.png', 'jar'=>'jar.png', 'jpg'=>'jpg.png', 'js'=>'js.png', 'log'=>'log.png', 'mdb'=>'mdb.png', 'mid'=>'mid.png', 'mp3'=>'mp3.png', 'php'=>'php.png', 'png'=>'png.png', 'ppt'=>'ppt.png', 'psd'=>'psd.png', 'py'=>'py.png', 'rar'=>'rar.png', 'rtf'=>'rtf.png', 'sql'=>'sql.png', 'swf'=>'swf.png', 'ttf'=>'ttf.png', 'txt'=>'txt.png', 'unkn'=>'unkn.png', 'wav'=>'wav.png', 'wml'=>'wml.png', 'wmv'=>'wmv.png', 'xls'=>'xls.png', 'xml'=>'xml.png', 'zip'=>'zip.png');

/* Host truy cập manager */
$configs['manager_url'] = 'http://kenhvh.tk/IManager/manager-xtgem';

/* Tài khoản đăng nhập quảng lý */
$configs['username'] = 'admin';
$configs['password'] = '22031999';

/* Sử dụng user-agent của trình duyệt wap, Không cần thiết thì khỏi phải đổi */
$configs['ua'] = 'Opera/9.80 (Series 60; Opera Mini/7.0.32400/28.3392; U; vi) Presto/2.8.119 Version/11.10';

/* Đường dẫn lưu cookie đăng nhập quản lý, nên thay đổi để bảo mật */
$configs['cookie'] = $root.'/files/cache/tammannager_607032400283392.txt';

/*Đối với autologin, sử dụng nhiều site bằng cách thêm nhiều mảng con*/
$configs['autologin']  = array(
		array(
			'title' => 'kenhvh',
			'link' => 'http://xtgem.com/autologin/ff848706477823794803512a70ae5e00/a2VuaHZoLm1vYmllLmlu'),
		/*array(
			'title' => 'site_1',
			'link' => 'http://xtgem.com/autologin/site_1'),*/
		/*array(
			'title' => 'site_2',
			'link' => 'http://xtgem.com/autologin/site_2'),*/
	);

