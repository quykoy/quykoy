<?php
/**********************************/
/*  Xtgem & Sextgem Mangager      */
/*  Code by MrTam 				  */
/*  Email: mr.trinhtam@yahoo.com  */
/*  Website: http://taigi.org 	  */
/**********************************/

if(!defined('__TAMMANAGER')) exit('Truy cap khong hop le');

function login(){
	global $configs;
	if($_SESSION['xt']['link']){
		file_put_contents($configs['cookie'],null);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
		curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['link']);
		curl_setopt($ch, CURLOPT_COOKIEJAR, $configs['cookie']);
		curl_exec($ch);
		curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
		curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser?a=&f=&file=/');
		$html = curl_exec($ch);
		if(preg_match('#token=(.*?)&#is', $html, $matches)){
			$_SESSION['xt']['token'] = @$matches[1];
			return $_SESSION['xt']['token'];
		}else{
			unlink($configs['cookie']);
			return false;
		}
	}else{
		return false;
	}
}
function showFile($file = null, $p = null){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser?only=files&a=&f=&file='.urlencode($file).($p?'&current_page='.$p:null));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(preg_match_all('/file_open\?file=(.*?)"(.*?)>(.*?)<\/a>/', $html, $out)){
		return array('link' => $out[1], 'name' => $out[3]);
	}else{
		return false;
	}
}
function showDir($file = null, $p = null){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser?only=dirs&a=&f=&file='.urlencode($file).($p?'&current_page='.$p:null));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	$html = explode('<div class="list">',$html);
	if(preg_match_all('/filebrowser\?a=&amp;f=&amp;file=(.*?)"(.*?)>(.*?)<\/a>/', $html[1], $out)){
		return array('link' => $out[1], 'name' => $out[3]);
	}else{
		return false;
	}
}
function showFullDir($file = null, $p = null){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser?&a=&f=&file='.urlencode($file).($p?'&current_page='.$p:null));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	$html=preg_replace('#<div class="padding">(.*?)</div>#is', '', $html);
	$list=array();
	preg_match_all('/filebrowser\?a=&amp;f=&amp;file=(.*?)"(.*?)>(.*?)<\/a>/', $html, $out);
	$list['dirs']=array('link' => $out[1], 'name' => $out[3]);
	preg_match_all('/filebrowser\/file_open\?file=(.*?)"(.*?)>(.*?)<\/a>/', $html, $out);
	$list['files']=array('link' => $out[1], 'name' => $out[3]);
	if(is_array($list['files']['name'])){
		foreach ($list['files']['name'] as $key => $value) {
			$list['files']['type'][$key]=end(explode('.', $value));
		}
	}
	if(preg_match_all('/filebrowser\?only=files/', $html)){
		$list['more_file']=true;
	}
	if(preg_match_all('/filebrowser\?only=dirs/', $html)){
		$list['more_dir']=true;
	}
	return $list;
}
function countDir($file = '/'){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser?only=dirs&a=&f=&file='.urlencode($file));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	$rt = 0;
	for($i=1000;$i>0;$i--){
		if(preg_match('|current_page='.$i.'|', $html)){
			$rt = $i;
			break;
		}
	}
	$file = showDir($file, $rt);
	return (($rt-1)*10)+count($file['link']);
}
function countFile($file = '/'){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser?only=files&a=&f=&file='.urlencode($file));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	$rt = 0;
	for($i=1000;$i>0;$i--){
		if(preg_match('|current_page='.$i.'|', $html)){
			$rt = $i;
			break;
		}
	}
	$file = showFile($file, $rt);
	return (($rt-1)*10)+count($file['link']);
}
function isDir($file){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_info?file='.urlencode($file));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(preg_match('#Properties#', $html)){
		return false;
	}else{
		return true;
	}
}
function fileExists($file){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_info?file='.urlencode($file));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(preg_match('#Rename#', $html)){
		return true;
	}else{
		return false;
	}
}
function newDir($dir, $name){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_save?__token='.$_SESSION['xt']['token'].'&act=new_dir&dir='.urlencode($dir));
	curl_setopt($ch, CURLOPT_POSTFIELDS, array('value' => $name, 'submit' => 'OK'));
	$html=curl_exec($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(preg_match('#success#', $html)){
		return true;
	}else{
		return false;
	}
}
function newFile($dir, $name){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_save?__token='.$_SESSION['xt']['token'].'&act=new_file&dir='.urlencode($dir));
	curl_setopt($ch, CURLOPT_POSTFIELDS, array('value' => $name, 'type' => 'txt', 'submit' => 'OK'));
	$html=curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(preg_match('#success#', $html)){
		return true;
	}else{
		return false;
	}
}
function renameFile($newname, $file){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_save?__token='.$_SESSION['xt']['token'].'&act=rename&file='.urlencode($file));
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, array('new_name' => $newname));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(preg_match('#success#', $html)){
		return true;
	}else{
		return false;
	}
}
function removeFile($file,$type){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_save?__token='.$_SESSION['xt']['token'].'&file='.urlencode($file).'&act=rm&msg='.($type=='dir'?'delete_dir':'delete_file'));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(preg_match('#success#', $html)){
		return true;
	}else{
		return false;
	}
}
function copyFile($file, $dir){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_save?__token='.$_SESSION['xt']['token'].'&act=cp&f='.urlencode($file).'&value='.urlencode($dir));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(preg_match('#success#', $html)){
		return true;
	}else{
		return false;
	}
}
function moveFile($file, $dir){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_save?__token='.$_SESSION['xt']['token'].'&act=mv&f='.urlencode($file).'&value='.urlencode($dir));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(preg_match('#success#', $html)){
		return true;
	}else{
		return false;
	}
}
function importFile($link, $dir='/'){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_upload_save?__token='.$_SESSION['xt']['token'].'&file='.urlencode($dir));
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, array('remote_file' => $link, 'upload_more'=>'y'));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(!preg_match('#error#', $html)){
		return true;
	}else{
		return false;
	}
}
function uploadFile($file, $dir='/'){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_upload?file='.urlencode($dir));
	$html = curl_exec($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	preg_match('#<input type="file" name="filext([a-z0-9]+)" \/>#', $html, $m);
	$filename = 'filext'.$m[1];
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_upload_save?__token='.$_SESSION['xt']['token'].'&file='.urlencode($dir));
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, array('MAX_FILE_SIZE' => '2097152', $filename => '@'.$file, 'upload_more' => 'y', 'submit' => 'OK'));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!preg_match('#error#', $html)){
		return true;
	}else{
		return false;
	}
}
function propertiesFile($file='/'){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_properties?file='.urlencode($dir));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	$data['link']=cutStr('<small>','</small>',$html);
	if($data['link']){
		$data['list']='<div class="list">'.trim(cutStr('<div class="list">','<a href',$html));
		$data['list']=str_replace('underline', 'data-item', $data['list']);
		return $data;
	}else{
		return false;
	}
}
function downloadFile($file='/index'){
	global $configs,$root;
	$file2=$file;
	$file=urlencode($file);
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_open?file='.$file);
	$html = curl_exec($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	$path=pathinfo($file2);
	$path=$path['dirname'];
	$file_path=$path.'/'.end(explode('/', $file2));
	createFullDir($root.'/files/download/',$path);
	if(preg_match('#edit_file#is', $html)||preg_match('#file_edit#is', $html)){
		curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_edit?file='.$file);
		$html = curl_exec($ch);
		curl_close($ch);
		$html=cutStr('<textarea cols="15" rows="15" name="value">','</textarea>',$html);
		if(file_put_contents($root.'/files/download/'.$file_path, htmlspecialchars_decode($html))){
			return $file_path;
		}else{
			return false;
		}
	}else{
        curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['site'].str_replace(' ', '+', $file2));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_REFERER, $_SESSION['xt']['site']);
        $data = curl_exec($ch);
        curl_close($ch);
		if(file_put_contents($root.'/files/download/'.$file_path, $data)){
			return $file_path;
		}else{
			return false;
		}
	}
}
function checkDir($dir='/'){
	global $configs;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $configs['ua']);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $configs['cookie']);
	curl_setopt($ch, CURLOPT_URL, $_SESSION['xt']['host'].'/filebrowser/file_upload?file='.urlencode($dir));
	$html = curl_exec($ch);
	curl_close($ch);
	if(!checkLogin($html)){
		return 'not_login';
	}
	if(preg_match('ddd', $html)){
		return true;
	}else{
		return false;
	}
}
function checkLogin($html){
	if(preg_match('#first_login#i', $html)){
		return false;
	}
	return true;
}
function cutStr($s,$e,$t){
	$t=explode($s, $t);
	$t=explode($e, $t[1]);
	return $t[0];
}
function createFullDir($root, $path){
	$ex = explode('/', $path);
	foreach ($ex as $val) {
		if($val){
			$root.=$val.DIRECTORY_SEPARATOR;
			if(!is_dir($root)){
				mkdir($root);
			}
		}
	}
}
function rmFullDir($dir){
	if($handle=opendir($dir)){
		while(($file=readdir($handle))<>false){
			if(is_file($dir.DIRECTORY_SEPARATOR.$file)){
				unlink($dir.DIRECTORY_SEPARATOR.$file);
			}else if (is_dir($dir.DIRECTORY_SEPARATOR.$file)&&($file<>".")&&($file<>"..")){
				rdir($dir.DIRECTORY_SEPARATOR.$file);
			}
		}
		closedir($handle);
		rmdir($dir);
	}
}