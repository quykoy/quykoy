<?php
$root=str_replace(DIRECTORY_SEPARATOR.'ajax', '', realpath(dirname(__FILE__)));
define('__TAMMANAGER',1);
include $root.DIRECTORY_SEPARATOR.'sys'.DIRECTORY_SEPARATOR.'configs.php';
header('location:'.$configs['manager_url'].'/login.php');
exit;