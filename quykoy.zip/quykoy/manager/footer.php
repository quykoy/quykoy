<?php if (!defined('ACCESS')) die('Not access'); ?>

        </div><div class="list"><center><b><a href="/quykoy/index.php">Phiên Phiên bản Manager 3.0</a> | <a href="/quykoy/manager-xtgem/index.php">Manager-Xtgem</a></b></center></div>
        <div id="footer">
            <span>Version <?php echo VERSION; ?> By ✔ Quý kÒy</span>
        </div>
    </body>
</html>
<?php ob_end_flush(); ?>