**** wap phpmyadmin ****
****    ionutvmi    ****

** INSTALL **
Replace the lang/index.php file with the index.php file from this archive


- to translate wap phpmyadmin in your language edit `index.php` file from current folder
- if you want to share your translation and make it available for other users send the translated version at ionutvmi@gmail.com